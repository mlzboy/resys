#! bin/sh
/home/mlzboy/bijia/test-redis-1.3.7/redis-server