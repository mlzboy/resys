#! bin/sh
rm /data/db/*.*
sudo /home/mlzboy/下载/mongodb-linux-i686-1.4.1/bin/mongod
